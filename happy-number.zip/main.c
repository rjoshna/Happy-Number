/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
//magic number
int main()
{
    int n,sum=0,rem,n1;
    printf("enter the value of n:");
    scanf("%d",&n);
    n1=n;
    while(n!=1 && n!=4){
        sum=0;
        while(n>0){
        rem=n%10;
        sum+=rem*rem;
        n=n/10;
        }
        n=sum;
       
    }
    if(n==1){
        printf("%d is a happy number\n",n1);
    }else{
        printf("%d is not a happy number\n",n1);
    }}
    